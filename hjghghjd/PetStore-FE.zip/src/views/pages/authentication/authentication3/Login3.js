import { Link } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';
import { Divider, Grid, Stack, Typography, useMediaQuery, Box ,Avatar} from '@mui/material';
import AuthWrapper1 from '../AuthWrapper1.js';
import AuthCardWrapper from '../AuthCardWrapper.js';
import AuthLogin from '../auth-forms/AuthLogin.js';
import Logo from 'layout/MainLayout/LogoSection';
import AuthFooter from 'ui-component/cards/AuthFooter.js';
import { getApi } from 'views/Api/comman.js';
import { urls } from 'views/Api/constant.js';
import { useEffect } from 'react';
import Pet from 'assets/images/pet-logo.jpg';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';


const Login = () => {
  const theme = useTheme();
  const matchDownSM = useMediaQuery(theme.breakpoints.down('sm'));
    const { t } = useTranslation();

  const [logo,setLogo] = useState(null)
  
  const fetchLogo = async () => {
    const response = await getApi(urls.register.get);
    setLogo(response?.data.data?.[0]);
  };

  useEffect(() => {
    fetchLogo();
  }, []);




  return (
    <AuthWrapper1>
      <Grid container sx={{ minHeight: '100vh', backgroundColor: '#A6CDC6',}}>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <AuthCardWrapper
            sx={{
              maxWidth: 400,
              width: '100%',
              boxShadow: theme.shadows[3],
              borderRadius: 2,
              backgroundColor: theme.palette.background.paper
            }}
          >
          <Grid container spacing={2} alignItems="center">
 
  <Grid item xs={12}>
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
        marginTop: '10px',
      }}
    >
      <Avatar
        alt="Logo Image"
        src={logo?.imageUr||Pet}
        sx={{
          width: 80,
          height: 80,
          borderRadius: '50%',
        }}
      />
    </Box>
  </Grid>


  <Grid item xs={12}>
    <Stack alignItems="center">
      <Typography variant="h3" sx={{ fontWeight: 700, textAlign: 'center', color:'#6A9C89' }}>
        {t("welcome")}
      </Typography>
      <Typography textAlign="center" variant="body2" sx={{ color: 'black' }}>
     {t("login")}
      </Typography>
    </Stack>
  </Grid>

  
  <Grid item xs={12}>
    <AuthLogin />
  </Grid>
</Grid>

          </AuthCardWrapper>
        </Grid>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Box
            sx={{
              width: '100%',
              height: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor:'#6A9C89',
              padding: '4px',
              flexDirection: 'column'
            }}
          >
            <Box
              component="img"
              src="https://img.freepik.com/free-vector/pet-shop-with-various-animals_1308-173352.jpg"
              alt="Inventory Management"
              sx={{
                maxWidth: '60%',
                maxHeight: '60%',
                objectFit: 'contain',
                borderRadius: '20px'
              }}
            />
            <Typography
              variant="h2"
              sx={{
                color: 'white',
                fontWeight: 'bold',
                textAlign: 'center',
                marginTop: '16px'
              }}
            >
           {t("title")} <br />
              <span style={{ fontSize: '12px' }}>{t("description_PetShop")}</span>
            </Typography>
          </Box>
        </Grid>
      </Grid>
    </AuthWrapper1>
  );
};
export default Login;