import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Person } from '@mui/icons-material';
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { Box, Grid, Typography, Card, CardActionArea } from '@mui/material';
import { getApi } from 'views/Api/comman';
import { urls } from 'views/Api/constant';
import BusinessIcon from '@mui/icons-material/Business';
import SkeletonTotalOrderCard from 'ui-component/cards/Skeleton/EarningCard';
import { useTranslation } from 'react-i18next';
const StyledCard = ({ children, onClick }) => (
  <Card
    sx={{
      color: '#6A9C89',
      overflow: 'hidden',
      position: 'relative',
      border: '1px solid #6A9C89',
      borderRadius: '12px',
      cursor: 'pointer',
      '&:hover': { boxShadow: '0 4px 15px rgba(106, 156, 137, 0.5)' }
    }}
  >
    <CardActionArea onClick={onClick}>{children}</CardActionArea>
  </Card>
);


const ShowOrder = ({ isLoading }) => {
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const { t } = useTranslation();
  const fetchCustomer = async () => {
    try {
      const response = await getApi(urls.customer.getCount);
      if (response?.data?.count) setCustomer(response.data.count || 0);
      else setCustomer(0);
    } catch (error) {
      console.error('Error fetching customer count:', error);
      setCustomer(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomer();
  }, []);

  
  const handleNavigate = () => navigate('/dashboard/addToCard');

  return (
    <>
      {isLoading || loading ? (
        <SkeletonTotalOrderCard />
      ) : (
        <StyledCard onClick={handleNavigate}>
          <Box sx={{ display: 'flex', alignItems: 'center', p: 2 }}>
          
            <Box
              sx={{
                backgroundColor: '#6A9C89',
                borderRadius: '50%',
                padding: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mr: 2
              }}
            >
              <ShoppingCartIcon sx={{ color: 'white', fontSize: '2rem' }} />
            </Box>

           
            <Grid container direction="column" justifyContent="center">
              
              <Typography
                sx={{
                  fontSize: '1rem',
                  color: '#6A9C89',
                  fontWeight: 600
                }}
              >
              {t("POS")}
              </Typography>
            </Grid>
          </Box>
        </StyledCard>
      )}
    </>
  );
};

ShowOrder.propTypes = {
  isLoading: PropTypes.bool
};

export default ShowOrder;
