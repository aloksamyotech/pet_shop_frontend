






const BulkUpload = () => {
return <>
<Typography>
    
</Typography>

</>
}
export default BulkUpload 